import React, { useState, useEffect } from 'react';
import { useFirebase } from './FirebaseContext';
import { PRESET_PROFILES, ParticipantProfile, UserProfile } from './firebase';
import { motion, AnimatePresence } from 'motion/react';
import FinanceiroView from './components/FinanceiroView';
import LogisticaView from './components/LogisticaView';
import AdminView from './components/AdminView';
import { 
  LogOut, 
  MapPin, 
  DollarSign, 
  Calendar, 
  Plane, 
  CheckCircle, 
  Clock, 
  Copy, 
  QrCode, 
  Lock, 
  UserCheck, 
  FileText, 
  ShieldAlert, 
  Sparkles,
  Smartphone,
  X,
  User
} from 'lucide-react';

const NETFLIX_AVATARS = [
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=RetroYan',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=PixJully',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=GameEnzo',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=SparkKev',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=VoltThi',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=ProtonJo',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=ByteLea',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=NanoAm',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=GizmoGi',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=MatrixTest',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Beta',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Sigma',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Gamma',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Omega',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Delta',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Shadow',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Speedy',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Chill',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Glitch',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Cosmo',
];

export default function App() {
  const { 
    connectionMode, 
    currentUser, 
    googleUser, 
    isAuthLoading, 
    loginWithProfile, 
    simulateGoogleLogin, 
    onLoginSuccess,
    logout,
    errorMsg,
    clearError,
    pixKey,
    users,
    updateUserAvatar
  } = useFirebase();

  // Selected Profile state during the login transition
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
  
  // Custom states for simulated popup
  const [showSimulatedPopup, setShowSimulatedPopup] = useState(false);

  // Active Tab state for navigation
  const [activeTab, setActiveTab] = useState<'dashboard' | 'financeiro' | 'logistica' | 'admin'>('dashboard');

  // Pix key copy feedback state
  const [copiedPix, setCopiedPix] = useState(false);

  // Profile manager edit modes
  const [isManageMode, setIsManageMode] = useState(false);
  const [selectedManageProfile, setSelectedManageProfile] = useState<ParticipantProfile | null>(null);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);

  // Redirect non-admin if somehow in admin tab
  useEffect(() => {
    if (currentUser && currentUser.role !== 'admin' && activeTab === 'admin') {
      setActiveTab('dashboard');
    }
  }, [currentUser, activeTab]);

  // Auto-detection of profile click
  const handleProfileClick = async (profile: ParticipantProfile) => {
    if (profile.id === 'teste_admin') {
      onLoginSuccess({
        id: 'teste_admin',
        nome: 'Teste Admin',
        role: 'admin',
        linkedUid: 'simulado123',
        email: 'teste@admin.com',
        totalPago: 0
      });
      return;
    }
    setSelectedProfileId(profile.id);
    if (connectionMode === 'offline_simulated') {
      // Show simulated Google Auth popup for testing
      setShowSimulatedPopup(true);
    } else {
      // Online Real Firebase Auth with Google popup
      try {
        await loginWithProfile(profile.id);
      } catch (e) {
        console.error(e);
      } finally {
        setSelectedProfileId(null);
      }
    }
  };

  const copyPixKey = () => {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  };

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#141414] text-white flex flex-col items-center justify-center p-4">
        <div className="h-12 w-12 border-4 border-red-600/30 border-t-red-600 rounded-full animate-spin"></div>
        <p className="mt-4 text-xs font-bold text-gray-400 tracking-wider uppercase animate-pulse">Sincronizando Viagem...</p>
      </div>
    );
  }

  // --- LOGIN SCREEN (NETFLIX STYLE) ---
  if (!currentUser) {
    const activeProf = PRESET_PROFILES.find(p => p.id === selectedProfileId);
    
    return (
      <div className="min-h-screen bg-[#141414] text-white flex flex-col justify-center items-center p-6 relative select-none">
        {/* Connection status badge top right */}
        <div className="absolute top-4 right-4 flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 rounded-full px-3 py-1 text-xs">
          <span className={`h-2.2 w-2.2 rounded-full ${connectionMode === 'online' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">
            {connectionMode === 'online' ? 'Online Real-Time' : 'Simulador Offline'}
          </span>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-3xl text-center space-y-8"
        >
          {/* Logo */}
          <div className="flex flex-col items-center gap-2">
            <span className="text-red-600 font-black tracking-widest text-4xl uppercase md:text-5xl font-sans">
              LAGOAFLIX
            </span>
            <p className="text-gray-400 text-xs tracking-wider uppercase font-extrabold max-w-md">
              Gestão da Viagem de Grupo Novembro 2026
            </p>
          </div>

          <div className="space-y-3">
            <h1 id="main-auth-title" className="text-2xl md:text-3.5xl font-bold tracking-tight">Quem está viajando?</h1>
            <p className="text-sm text-gray-405 text-neutral-400">Escolha seu perfil para continuar com a Conta Google.</p>
          </div>

          {/* Access denied warnings */}
          {errorMsg && (
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="max-w-md mx-auto p-4 bg-red-950/60 border border-red-800/80 rounded-xl flex items-start gap-3 text-red-100 text-xs text-left leading-relaxed"
            >
              <ShieldAlert className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-bold block text-sm">Bloqueio de Vínculo</span>
                <p>{errorMsg}</p>
                <button 
                  onClick={clearError}
                  className="mt-1.5 px-2 py-1 bg-red-900 hover:bg-red-800 text-white font-bold rounded text-[10px] transition uppercase cursor-pointer"
                >
                  Tentar Outro Perfil
                </button>
              </div>
            </motion.div>
          )}

          {/* Grid of Profiles (Netflix style) */}
          <div id="profiles-picker-grid" className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6 max-w-2xl mx-auto pt-4 pb-4">
            {PRESET_PROFILES.map((profile) => {
              const dbProfile = users?.find(u => u.id === profile.id);
              const hasCustomAvatar = dbProfile && dbProfile.avatarUrl;
              
              return (
                <motion.div 
                  key={profile.id}
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    if (isManageMode) {
                      setSelectedManageProfile(profile);
                      setIsAvatarModalOpen(true);
                    } else {
                      handleProfileClick(profile);
                    }
                  }}
                  className="group flex flex-col items-center gap-3 cursor-pointer relative"
                >
                  {/* Profile Box */}
                  <div className={`h-24 w-24 md:h-28 md:w-28 rounded-md ${profile.color} flex flex-col items-center justify-center relative transition ring-offset-4 ring-offset-neutral-950 group-hover:ring-3 group-hover:ring-white shadow-lg overflow-hidden`}>
                    {hasCustomAvatar ? (
                      <img src={dbProfile.avatarUrl} alt={profile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <span className="text-3xl font-black text-white uppercase select-none">
                        {profile.name.charAt(0)}
                      </span>
                    )}

                    {selectedProfileId === profile.id ? (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-md">
                        <div className="h-6 w-6 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                      </div>
                    ) : null}

                    {/* Pencil overlay if edit mode is active */}
                    {isManageMode && (
                      <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                        <div className="bg-black/90 rounded-full p-2 border border-white/30 hover:scale-110 transition duration-150">
                          <svg className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                          </svg>
                        </div>
                      </div>
                    )}

                    {profile.role === 'admin' && (
                      <span className="absolute bottom-1 right-1 bg-red-650 bg-red-600 text-white text-[8px] font-black tracking-widest uppercase px-1.5 py-0.5 rounded shadow">
                        Coord
                      </span>
                    )}
                  </div>

                  {/* Name Label */}
                  <span className="text-gray-400 group-hover:text-white transition font-semibold text-sm md:text-base leading-tight">
                    {profile.name}
                  </span>
                </motion.div>
              );
            })}
          </div>

          <div className="pt-4 pb-2">
            <button
              onClick={() => setIsManageMode(!isManageMode)}
              className={`px-6 py-2.5 border font-bold tracking-wider rounded text-xs transition uppercase whitespace-nowrap cursor-pointer ${
                isManageMode 
                  ? 'border-white bg-white text-black hover:bg-neutral-200' 
                  : 'border-neutral-600 text-neutral-400 hover:border-white hover:text-white'
              }`}
            >
              {isManageMode ? 'Concluído' : 'Gerenciar Perfis'}
            </button>
          </div>
        </motion.div>

        {/* AVATAR CHOOSER MODAL */}
        <AnimatePresence>
          {isAvatarModalOpen && selectedManageProfile && (
            <div className="fixed inset-0 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-[#181818] border border-neutral-800 rounded-2xl w-full max-w-xl p-6 md:p-8 space-y-6 text-left relative shadow-2xl"
              >
                <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
                  <div>
                    <span className="text-red-500 font-extrabold uppercase text-[10px] tracking-widest">Personalizar Perfil</span>
                    <h3 className="text-xl font-bold tracking-tight text-white mt-1">
                      Escolha um avatar para {selectedManageProfile.name}
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      setIsAvatarModalOpen(false);
                      setSelectedManageProfile(null);
                    }}
                    className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition border border-neutral-800 cursor-pointer"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                {/* 20 Avatars Grid */}
                <div className="grid grid-cols-4 sm:grid-cols-5 gap-4 max-h-[350px] overflow-y-auto pr-1">
                  {NETFLIX_AVATARS.map((url, idx) => (
                    <motion.div
                      key={idx}
                      whileHover={{ scale: 1.08 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={async () => {
                        try {
                          await updateUserAvatar(selectedManageProfile.id, url);
                          setIsAvatarModalOpen(false);
                          setSelectedManageProfile(null);
                        } catch (e) {
                          console.error(e);
                        }
                      }}
                      className="aspect-square bg-neutral-900 border-2 border-transparent hover:border-red-600 rounded-md overflow-hidden cursor-pointer shadow-md transition"
                    >
                      <img src={url} alt={`Avatar option ${idx + 1}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </motion.div>
                  ))}
                </div>

                <div className="flex justify-start border-t border-neutral-800 pt-4">
                  <button
                    onClick={() => {
                      setIsAvatarModalOpen(false);
                      setSelectedManageProfile(null);
                    }}
                    className="px-5 py-2 bg-neutral-800 hover:bg-neutral-700 text-white font-bold rounded text-xs transition uppercase cursor-pointer"
                  >
                    Voltar
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* SIMULATED GOOGLE AUTH POPUP (Offline mode test-drive) */}
        <AnimatePresence>
          {showSimulatedPopup && activeProf && (
            <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
              <motion.div 
                initial={{ scale: 0.92, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.92, opacity: 0 }}
                className="bg-white text-gray-900 rounded-3xl p-6 w-full max-w-sm border border-neutral-300 shadow-2xl relative space-y-6"
              >
                {/* Header */}
                <div className="text-center space-y-3.5">
                  <div className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 mb-1">
                    <svg className="h-5 w-5" viewBox="0 0 24 24">
                      <path fill="#EA4335" d="M12 5.04c1.61 0 3.09.55 4.22 1.62l3.15-3.15C17.43 1.68 14.9.75 12 .75 7.35.75 3.39 3.42 1.5 7.28l3.86 3C6.27 7.42 8.91 5.04 12 5.04z" />
                      <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.35H12v4.51h6.46c-.29 1.48-1.14 2.73-2.43 3.58l3.77 2.92c2.2-2.03 3.69-5.03 3.69-8.66z" />
                      <path fill="#FBBC05" d="M5.36 14.68c-.24-.72-.38-1.49-.38-2.28 0-.79.14-1.56.38-2.28L1.5 7.12C.54 9.07 0 11.24 0 12.5s.54 3.43 1.5 5.38l3.86-3.2z" />
                      <path fill="#34A853" d="M12 23.25c3.24 0 5.97-1.07 7.96-2.91l-3.77-2.92c-1.05.7-2.39 1.11-4.19 1.11-3.09 0-5.73-2.38-6.64-5.24L1.5 16.53c1.89 3.86 5.85 6.72 10.5 6.72z" />
                    </svg>
                  </div>
                  <h3 className="text-base font-extrabold text-gray-800 leading-tight">Painel de Login do Google</h3>
                  <p className="text-xs text-gray-500 font-medium">Você escolheu o perfil de <span className="font-extrabold text-gray-800">{activeProf.name}</span>.</p>
                </div>

                {/* Warning message explaining simulation */}
                <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-amber-800 text-[11px] leading-relaxed font-normal">
                  Este é o <strong>Modo Simulador</strong>. Escolha abaixo como simular a autenticação Google Auth.
                </div>

                <div className="space-y-3.5 pt-1">
                  <button
                    onClick={() => {
                      simulateGoogleLogin(activeProf.id, `${activeProf.id}@gmail.com`, activeProf.name);
                      setShowSimulatedPopup(false);
                      setSelectedProfileId(null);
                    }}
                    className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold leading-tight transition cursor-pointer select-none"
                  >
                    Simular Conta Google CORRETA
                  </button>
                  
                  <button
                    onClick={() => {
                      // Login incorrectly using an arbitrary uid to simulate access denied / locked account
                      const fakeUsersList = ['guest_test_999'];
                      localStorage.setItem('bt_profile_id', activeProf.id);
                      localStorage.setItem('bt_sim_auth', 'true');
                      useFirebase().simulateGoogleLogin(activeProf.id, `other_hacker_email@gmail.com`, "Outro Usuário");
                      setShowSimulatedPopup(false);
                      setSelectedProfileId(null);
                    }}
                    className="w-full py-2.5 bg-red-50 hover:bg-red-100 text-red-650 text-red-600 rounded-xl text-xs font-bold leading-tight transition cursor-pointer select-none"
                  >
                    Simular Conta Google INCORRETA (Outro)
                  </button>
                </div>

                <button
                  onClick={() => {
                    setShowSimulatedPopup(false);
                    setSelectedProfileId(null);
                  }}
                  className="w-full text-center text-xs text-gray-400 hover:text-gray-600 transition"
                >
                  Cancelar
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Footer credits inside black authentication page */}
        <p className="absolute bottom-6 text-[10px] text-zinc-600 font-extrabold uppercase tracking-widest select-none">
          LagoaFlix • Design Netflix com Firebase Auth Vias de Vínculo
        </p>
      </div>
    );
  }

  // --- MAIN APP COMPONENT (LOGGED IN SCREEN) ---
  return (
    <div className="min-h-screen bg-[#fafafa] text-slate-900 flex flex-col md:pb-0 select-none pb-20 selection:bg-red-100 selection:text-red-900">
      
      {/* Dynamic Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-150 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          
          {/* Logo Heading */}
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-xl bg-red-600 text-white flex items-center justify-center font-black shadow-xs">
              <Plane className="h-5 w-5 transform -rotate-12" />
            </div>
            <div>
              <h1 className="text-xs font-black text-slate-800 uppercase tracking-tight leading-3">Campo Limpo Paulista - SP</h1>
              <p className="text-[9px] text-gray-450 text-slate-400 font-black tracking-widest uppercase">AMIGOS EM GRUPO</p>
            </div>
          </div>

          {/* User Widget */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 bg-slate-100 rounded-full px-3 py-1">
              {currentUser.avatarUrl ? (
                <img src={currentUser.avatarUrl} alt={currentUser.nome} className="h-6 w-6 rounded-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="h-6 w-6 rounded-full bg-red-100 text-red-650 text-red-600 flex items-center justify-center text-[11px] font-black uppercase font-sans">
                  {currentUser.nome.charAt(0)}
                </div>
              )}
              <div className="text-left hidden md:block select-none">
                <span className="text-[10px] font-bold text-slate-700 block leading-3 truncate max-w-[100px]">{currentUser.nome}</span>
                <span className="text-[8px] text-slate-400 uppercase font-extrabold tracking-widest leading-none">
                  {currentUser.role === 'admin' ? 'Coordenador' : 'Viajante'}
                </span>
              </div>
            </div>

            {/* Logout Trigger */}
            <button
              onClick={logout}
              className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-xl transition cursor-pointer"
              title="Sair do Perfil"
            >
              <LogOut className="h-4.5 w-4.5" />
            </button>
          </div>

        </div>
      </header>

      {/* Main Workspace Frame */}
      <main className="flex-1 px-4 py-6 max-w-4xl w-full mx-auto space-y-6">
        {activeTab === 'dashboard' && <DashboardView />}
        {activeTab === 'financeiro' && <FinanceiroView />}
        {activeTab === 'logistica' && <LogisticaView />}
        {activeTab === 'admin' && currentUser?.role === 'admin' && <AdminView />}
      </main>

      {/* Dynamic Bottom Mobile-First Navigation Frame */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-gray-150 py-2 sm:py-3 px-4 shadow-lg md:relative md:border-t md:border-b md:shadow-none md:bg-white md:rounded-3xl md:max-w-md md:mx-auto md:mb-6 md:px-6">
        <div className="flex items-center justify-around md:gap-4 select-none">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center gap-1.5 transition text-[10px] font-extrabold tracking-tight cursor-pointer ${
              activeTab === 'dashboard' ? 'text-red-650 text-red-600 font-bold scale-105' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            🗺️ <span className="uppercase block text-[9px] font-black tracking-wider font-sans">Painel</span>
          </button>

          <button
            onClick={() => setActiveTab('financeiro')}
            className={`flex flex-col items-center gap-1.5 transition text-[10px] font-extrabold tracking-tight cursor-pointer ${
              activeTab === 'financeiro' ? 'text-red-650 text-red-600 font-bold scale-105' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            💳 <span className="uppercase block text-[9px] font-black tracking-wider font-sans">Financeiro</span>
          </button>

          <button
            onClick={() => setActiveTab('logistica')}
            className={`flex flex-col items-center gap-1.5 transition text-[10px] font-extrabold tracking-tight cursor-pointer ${
              activeTab === 'logistica' ? 'text-red-650 text-red-600 font-bold scale-105' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            🚗 <span className="uppercase block text-[9px] font-black tracking-wider font-sans">Logística</span>
          </button>

          {currentUser?.role === 'admin' && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`flex flex-col items-center gap-1.5 transition text-[10px] font-extrabold tracking-tight cursor-pointer ${
                activeTab === 'admin' ? 'text-red-650 text-red-600 font-bold scale-105' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              🛡️ <span className="uppercase block text-[9px] font-black tracking-wider font-sans">Admin</span>
            </button>
          )}
        </div>
      </nav>

    </div>
  );
}

// ============================================================================
// COMPONENT 1: DASHBOARD VIEW
// ============================================================================
function DashboardView() {
  const { users, currentUser, logistica, pixKey } = useFirebase();

  // Pix state
  const [copiedPix, setCopiedPix] = useState(false);

  // Time remaining Countdown Dec 15th, 2026
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
  });

  useEffect(() => {
    const calculateTime = () => {
      // Countdown date until November 18th, 2026
      const targetDate = new Date('2026-11-18T20:00:00').getTime();
      const now = new Date().getTime();
      const diff = targetDate - now;

      if (diff > 0) {
        const d = Math.floor(diff / (1000 * 60 * 60 * 24));
        const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        setTimeLeft({ days: d, hours: h, minutes: m });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0 });
      }
    };

    calculateTime();
    const interval = setInterval(calculateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  const copyPixKey = () => {
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  // Human date parser
  const getReadableDateTime = (dateStr?: string) => {
    if (!dateStr) return 'Não definido';
    const date = new Date(dateStr);
    return date.toLocaleString('pt-BR', {
      day: '2-digit',
      month: 'long',
      hour: '2-digit',
      minute: '2-digit'
    }) + 'h';
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* 1. HERO CONTADOR DE DEZEMBRO CARD */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 text-white overflow-hidden relative flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md shadow-neutral-950/10">
        <div className="absolute top-0 right-0 h-40 w-40 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="space-y-2 relative z-10 text-left">
          <span className="text-[10px] text-red-500 font-extrabold uppercase tracking-widest bg-red-950/60 border border-red-900/60 px-3 py-1 rounded-full">
            Contagem Regressiva
          </span>
          <h2 className="text-xl font-black text-white tracking-tight">Sítio em Campo Limpo Paulista - SP</h2>
          <p className="text-xs text-neutral-400 font-medium">Novembro de 2026 promete! Preparem os casacos, trajes de banho e a animação.</p>
        </div>

        {/* Big Countdown */}
        <div className="flex items-center gap-3.5 bg-neutral-950/50 border border-neutral-800/80 rounded-2xl p-4 font-mono w-fit relative z-10">
          <div className="text-center min-w-[42px]">
            <span className="block text-2xl font-black text-white leading-tight">{timeLeft.days}</span>
            <span className="text-[8px] text-gray-500 uppercase font-black tracking-wider block">Dias</span>
          </div>
          <span className="text-red-600 text-lg font-bold -mt-3">:</span>
          <div className="text-center min-w-[42px]">
            <span className="block text-2xl font-black text-white leading-tight">{timeLeft.hours}</span>
            <span className="text-[8px] text-gray-500 uppercase font-black tracking-wider block">Horas</span>
          </div>
          <span className="text-red-600 text-lg font-bold -mt-3">:</span>
          <div className="text-center min-w-[42px]">
            <span className="block text-2xl font-black text-white leading-tight">{timeLeft.minutes}</span>
            <span className="text-[8px] text-gray-500 uppercase font-black tracking-wider block">Mins</span>
          </div>
        </div>
      </div>

      {/* 2. CRONOGRAMA & DATAS */}
      <div className="bg-white rounded-3xl p-5 border border-gray-150 shadow-xs space-y-4 text-left">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-red-600" />
          <h3 className="text-sm font-extrabold text-slate-800 tracking-tight">Cronograma de Viagem</h3>
        </div>

        {logistica ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-50 border border-gray-100 rounded-2xl p-4 flex items-start gap-3">
              <span className="h-2 w-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
              <div className="space-y-1">
                <span className="text-[9px] text-slate-400 uppercase font-black block tracking-wider">Data de Ida (Embarque)</span>
                <span className="text-xs font-bold text-slate-750 leading-tight block">
                  {getReadableDateTime(logistica.dataIda)}
                </span>
                <span className="text-[10px] text-slate-500 font-medium block">De: {logistica.enderecoPartida}</span>
              </div>
            </div>

            <div className="bg-slate-50 border border-gray-100 rounded-2xl p-4 flex items-start gap-3">
              <span className="h-2 w-2 rounded-full bg-red-500 mt-1.5 shrink-0" />
              <div className="space-y-1">
                <span className="text-[9px] text-slate-400 uppercase font-black block tracking-wider">Data de Volta (Retorno)</span>
                <span className="text-xs font-bold text-slate-755 leading-tight block">
                  {getReadableDateTime(logistica.dataVolta)}
                </span>
                <span className="text-[10px] text-slate-500 font-medium block">Para: {logistica.enderecoPartida}</span>
              </div>
            </div>
          </div>
        ) : (
          <p className="text-xs text-gray-500">Nenhum cronograma definido ainda.</p>
        )}
      </div>

      {/* Grid of details: MEU PAGAMENTO, PARTICIPANTES, AÇÕES PIX */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Meu Pagamento Status */}
        <div className="bg-white rounded-3xl p-5 border border-gray-150 shadow-xs text-left flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-red-600" />
                <h3 className="text-sm font-extrabold text-slate-800 tracking-tight">Meu Pagamento</h3>
              </div>
              <span className="text-[9px] bg-red-50 border border-red-100/50 text-red-600 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                Individual
              </span>
            </div>

            <div className="bg-neutral-900 text-white rounded-2xl p-4 flex items-center justify-between relative overflow-hidden">
              <div className="space-y-0.5 relative z-10">
                <span className="text-[9px] text-gray-400 uppercase font-black tracking-wider block">Seu Total Pago</span>
                <span className="text-2xl font-mono font-black">{formatCurrency(currentUser?.totalPago || 0)}</span>
              </div>
              <div className="z-10 text-right">
                <span className="text-[10px] text-neutral-300 font-bold block bg-neutral-800 border border-neutral-700 px-2 py-1 rounded-lg">
                  {currentUser?.totalPago && currentUser.totalPago >= 500 ? 'Quitação Concluída' : 'Em andamento'}
                </span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-gray-100 rounded-2xl text-[11px] text-slate-500 leading-normal font-normal">
            A meta mínima estimada para a hospedagem e custos básicos por participante é de <strong className="text-slate-800">R$ 500,00</strong>. Continue enviando comprovantes.
          </div>
        </div>

        {/* Ações Pix Card */}
        <div className="bg-white rounded-3xl p-5 border border-gray-150 shadow-xs text-left space-y-4">
          <div className="flex items-center gap-2">
            <QrCode className="h-5 w-5 text-red-600" />
            <h3 className="text-sm font-extrabold text-slate-800 tracking-tight">Depósito Pix Rápido</h3>
          </div>

          <p className="text-[11px] text-slate-500 leading-relaxed font-normal">
            Faça doações, depósitos mensais de parcelamento ou pagamentos de despesas de forma centralizada e direta.
          </p>

          <div className="bg-slate-50 border border-gray-100 rounded-2xl p-3.5 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 font-bold">Chave Pix Coleta:</span>
              <span className="bg-white border border-gray-200/60 text-slate-700 font-mono font-bold px-2 py-1 rounded text-[11px]">
                {pixKey}
              </span>
            </div>
            
            <button
              onClick={copyPixKey}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold tracking-tight transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Copy className="h-3.5 w-3.5" />
              {copiedPix ? 'Chave Copiada!' : 'Copiar Chave Pix'}
            </button>
          </div>
        </div>

      </div>

      {/* 3. LISTA DE PARTICIPANTES COMPACT */}
      <div className="bg-white rounded-3xl p-5 border border-gray-150 shadow-xs text-left space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserCheck className="h-5 w-5 text-red-600" />
            <h3 className="text-sm font-extrabold text-slate-800 tracking-tight">Participantes da Viagem</h3>
          </div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono">
            Total: {users.length}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
          {users.map((user) => (
            <div 
              key={user.id}
              className="bg-slate-50 border border-gray-100 rounded-2xl p-3 flex.5 flex items-center justify-between relative"
            >
              <div className="flex items-center gap-2.5">
                <div className="h-8 w-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center font-bold text-xs">
                  {user.nome.charAt(0).toUpperCase()}
                </div>
                <div>
                  <span className="text-xs font-extrabold text-slate-800 block truncate max-w-[120px]">
                    {user.nome}
                  </span>
                  <span className="text-[9px] uppercase tracking-wider font-bold text-slate-400">
                    {user.role === 'admin' ? 'Coordenador' : 'Viajante'}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] font-mono font-black text-slate-750 block">
                  {formatCurrency(user.totalPago || 0)}
                </span>
                <span className="text-[8px] uppercase tracking-widest font-bold text-slate-400">Total Pago</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </motion.div>
  );
}




