import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet, 
  Table, 
  ArrowLeft, 
  Upload, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  Trash2, 
  Plus, 
  AlertCircle,
  FileText,
  DollarSign,
  Loader2
} from 'lucide-react';
import { useFirebase } from '../FirebaseContext';
import { storage } from '../firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export default function FinanceiroView() {
  const { 
    currentUser, 
    connectionMode, 
    isFirebaseOnline, 
    users, 
    pagamentos, 
    gastos, 
    addPagamento, 
    addGasto, 
    deleteGasto 
  } = useFirebase();

  // internal navigation: 'menu', 'pagamentos', 'planilha'
  const [activeView, setActiveView] = useState<'menu' | 'pagamentos' | 'planilha'>('menu');

  // Payment upload form states
  const [valorPagamento, setValorPagamento] = useState('');
  const [refPagamento, setRefPagamento] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // New expense form states (exclusive for admins)
  const [novaDescricao, setNovaDescricao] = useState('');
  const [novoValor, setNovoValor] = useState('');
  const [novaCategoria, setNovaCategoria] = useState<'Moradia' | 'Transporte' | 'Alimentação' | 'Outros'>('Moradia');
  const [adicionandoGasto, setAdicionandoGasto] = useState(false);

  // Handle payment registration
  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitSuccess(null);

    const valorNum = parseFloat(valorPagamento);
    if (isNaN(valorNum) || valorNum <= 0) {
      setErrorMsg('Por favor, informe um valor de pagamento válido.');
      return;
    }
    if (!refPagamento.trim()) {
      setErrorMsg('Por favor, informe uma referência (ex: Mês ou Descrição).');
      return;
    }
    if (!selectedFile) {
      setErrorMsg('Por favor, selecione um arquivo de comprovante (PDF ou Imagem).');
      return;
    }

    setUploading(true);
    try {
      let downloadUrl = 'https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=800'; // Fallback / mock url
      const userUid = currentUser?.linkedUid || currentUser?.id || 'simulado123';

      if (connectionMode === 'online' && isFirebaseOnline && storage) {
        // Upload to real storage: /comprovantes/{currentUser.uid}/{nome_do_arquivo}
        const storageRef = ref(storage, `comprovantes/${userUid}/${Date.now()}_${selectedFile.name}`);
        const snapshot = await uploadBytes(storageRef, selectedFile);
        downloadUrl = await getDownloadURL(snapshot.ref);
      } else {
        // Simulated offline delay
        await new Promise((resolve) => setTimeout(resolve, 1500));
        // Create active object URL for offline inspection of the actual upload if desired
        try {
          downloadUrl = URL.createObjectURL(selectedFile);
        } catch (_) {
          // ignore fallback index
        }
      }

      await addPagamento(valorNum, refPagamento.trim(), downloadUrl);
      
      setSubmitSuccess('Comprovante enviado com sucesso! Aguardando homologação do administrador.');
      setValorPagamento('');
      setRefPagamento('');
      setSelectedFile(null);
      // Clean target file input
      const fileInput = document.getElementById('comprovante_file_input') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    } catch (err: any) {
      console.error('Erro ao enviar pagamento:', err);
      setErrorMsg(err.message || 'Falha ao processar o envio do comprovante. Tente novamente.');
    } finally {
      setUploading(false);
    }
  };

  // Add new expense (for planilhas)
  const handleAddGasto = async (e: React.FormEvent) => {
    e.preventDefault();
    const valorNum = parseFloat(novoValor);
    if (!novaDescricao.trim() || isNaN(valorNum) || valorNum <= 0) {
      alert('Preencha os campos de descrição e valor corretamente.');
      return;
    }

    setAdicionandoGasto(true);
    try {
      await addGasto(novaCategoria, novaDescricao.trim(), valorNum);
      setNovaDescricao('');
      setNovoValor('');
    } catch (err) {
      console.error('Erro ao adicionar gasto:', err);
      alert('Erro ao registrar o gasto.');
    } finally {
      setAdicionandoGasto(false);
    }
  };

  const handleDeleteGasto = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir este item da planilha de gastos?')) {
      try {
        await deleteGasto(id);
      } catch (err) {
        console.error('Erro ao deletar gasto:', err);
        alert('Falha ao excluir o gasto.');
      }
    }
  };

  // Safe categorization lists
  const filterAndSumByCategory = (cat: 'Moradia' | 'Transporte' | 'Alimentação' | 'Outros') => {
    const list = gastos.filter(g => g.categoria === cat);
    const sum = list.reduce((acc, curr) => acc + (curr.valor || 0), 0);
    return { list, sum };
  };

  const moradia = filterAndSumByCategory('Moradia');
  const transporte = filterAndSumByCategory('Transporte');
  const alimentacao = filterAndSumByCategory('Alimentação');
  const outros = filterAndSumByCategory('Outros');

  const totalGeralGastos = moradia.sum + transporte.sum + alimentacao.sum + outros.sum;

  return (
    <div id="financeiro_view_container" className="w-full">
      <AnimatePresence mode="wait">
        
        {/* VIEW 1: MENU INICIAL */}
        {activeView === 'menu' && (
          <motion.div
            key="menu"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto w-full px-2"
          >
            {/* Card 1: Pagamentos */}
            <button
              id="btn_view_pagamentos"
              onClick={() => setActiveView('pagamentos')}
              className="flex flex-col items-center text-center p-8 bg-white border border-gray-150 rounded-3xl shadow-sm hover:shadow-md hover:border-red-300 transition-all duration-300 group cursor-pointer"
            >
              <div className="h-16 w-16 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Wallet className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800 group-hover:text-red-600 transition-colors">
                Pagamentos e Comprovantes
              </h3>
              <p className="text-sm text-neutral-500 mt-2 leading-relaxed max-w-xs">
                Envie seus recibos de transferência e acompanhe o ranking de pagamentos do grupo.
              </p>
              <div className="mt-6 inline-flex items-center text-xs font-semibold text-red-500 group-hover:translate-x-1 transition-transform">
                Acessar Área de Pagamentos &rarr;
              </div>
            </button>

            {/* Card 2: Planilha */}
            <button
              id="btn_view_planilha"
              onClick={() => setActiveView('planilha')}
              className="flex flex-col items-center text-center p-8 bg-white border border-gray-150 rounded-3xl shadow-sm hover:shadow-md hover:border-red-300 transition-all duration-300 group cursor-pointer"
            >
              <div className="h-16 w-16 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Table className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800 group-hover:text-red-600 transition-colors">
                Planilha de Gastos
              </h3>
              <p className="text-sm text-neutral-500 mt-2 leading-relaxed max-w-xs">
                Veja o detalhamento dos custos divididos por Moradia, Alimentação, Transporte e mais.
              </p>
              <div className="mt-6 inline-flex items-center text-xs font-semibold text-red-500 group-hover:translate-x-1 transition-transform">
                Consultar Custos Detalhados &rarr;
              </div>
            </button>
          </motion.div>
        )}

        {/* VIEW 2: PAGAMENTOS */}
        {activeView === 'pagamentos' && (
          <motion.div
            key="pagamentos"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-6 max-w-4xl mx-auto w-full px-2"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn_back_to_menu_comprovantes"
                onClick={() => setActiveView('menu')}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 hover:text-red-500 transition-colors uppercase tracking-wider text-xs"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar ao Menu
              </button>
              <span className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full uppercase">
                Área de Pagamentos
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Seção A: Formulário de Envio */}
              <div className="lg:col-span-7 bg-white rounded-3xl border border-gray-150 shadow-sm p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
                    <Upload className="h-5 w-5 text-red-500" />
                    Enviar Comprovante
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1">
                    Insira as informações correspondentes ao depósito ou transferência efetuada para a conta da viagem.
                  </p>
                </div>

                <form onSubmit={handlePaymentSubmit} id="form_comprovante" className="space-y-4">
                  {errorMsg && (
                    <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {submitSuccess && (
                    <div className="p-3 bg-emerald-50 border border-emerald-250 text-emerald-700 rounded-xl text-xs flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
                      <span>{submitSuccess}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">
                        Valor Pago (R$) *
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-xs text-neutral-400 font-bold">R$</span>
                        <input
                          id="input_comprovante_valor"
                          type="number"
                          step="0.01"
                          placeholder="0,00"
                          value={valorPagamento}
                          onChange={(e) => setValorPagamento(e.target.value)}
                          required
                          className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400 focus:border-red-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">
                        Referência / Mês *
                      </label>
                      <input
                        id="input_comprovante_ref"
                        type="text"
                        placeholder="Ex: Janeiro, Parcela 2, Mercado"
                        value={refPagamento}
                        onChange={(e) => setRefPagamento(e.target.value)}
                        required
                        className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-400 focus:border-red-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">
                      Comprovante (Imagem ou PDF) *
                    </label>
                    <div className="border-2 border-dashed border-gray-200 hover:border-red-400 rounded-2xl p-4 transition-colors relative flex flex-col items-center justify-center bg-slate-50">
                      <input
                        id="comprovante_file_input"
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setSelectedFile(e.target.files[0]);
                          }
                        }}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                        required
                      />
                      <FileText className="h-8 w-8 text-neutral-400 mb-2" />
                      {selectedFile ? (
                        <div className="text-center">
                          <p className="text-xs font-bold text-slate-700 truncate max-w-xs">{selectedFile.name}</p>
                          <p className="text-[10px] text-neutral-400 mt-0.5">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                        </div>
                      ) : (
                        <p className="text-xs text-neutral-450 text-center">
                          Arraste seu comprovante aqui ou <strong className="text-red-500 font-extrabold">clique para buscar</strong>
                        </p>
                      )}
                    </div>
                  </div>

                  <button
                    id="btn_submit_comprovante"
                    type="submit"
                    disabled={uploading}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white font-extrabold text-sm py-3 px-4 rounded-xl shadow-sm hover:shadow-md transition-all active:scale-[0.99] disabled:opacity-75 disabled:pointer-events-none"
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Fazendo upload e registrando...</span>
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4" />
                        <span>Enviar Comprovante</span>
                      </>
                    )}
                  </button>
                </form>

                {/* Histórico Recente de Pagamentos Pessoais */}
                <div className="pt-4 border-t border-gray-100">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                    Seus Envios Recentes
                  </h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {pagamentos
                      .filter(p => p.uid === currentUser?.id)
                      .map((p) => (
                        <div key={p.id} className="flex items-center justify-between p-3 bg-slate-50 border border-gray-100 rounded-xl text-xs">
                          <div>
                            <p className="font-extrabold text-slate-700">R$ {p.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                            <p className="text-[10px] text-neutral-400">{p.mesRef}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <a
                              href={p.comprovanteUrl}
                              target="_blank"
                              rel="no-referrer noreferrer"
                              className="text-[10px] text-red-500 font-bold hover:underline"
                            >
                              Ver Recibo
                            </a>
                            {p.status === 'aprovado' ? (
                              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-600 px-2.5 py-1 rounded-full text-[10px] font-bold">
                                <CheckCircle2 className="h-3 w-3" /> Aprovado
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-500 px-2.5 py-1 rounded-full text-[10px] font-bold">
                                <Clock className="h-3 w-3 animate-pulse" /> Pendente
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    {pagamentos.filter(p => p.uid === currentUser?.id).length === 0 && (
                      <p className="text-center text-xs text-slate-400 py-3 italic">Nenhum pagamento registrado ainda.</p>
                    )}
                  </div>
                </div>

              </div>

              {/* Seção B: Ranking de Participantes */}
              <div className="lg:col-span-5 bg-white rounded-3xl border border-gray-150 shadow-sm p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-red-500" />
                    Ranking Financeiro
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1">
                    Total pago homologado por participante para custeio geral da viagem.
                  </p>
                </div>

                <div className="space-y-3">
                  {users
                    .sort((a, b) => (b.totalPago || 0) - (a.totalPago || 0))
                    .map((user, idx) => {
                      const totalFormatado = (user.totalPago || 0).toLocaleString('pt-BR', {
                        style: 'currency',
                        currency: 'BRL',
                      });
                      
                      return (
                        <div 
                          key={user.id} 
                          className="flex items-center justify-between p-3.5 bg-slate-50 hover:bg-slate-100 border border-gray-100 rounded-2xl transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-xs font-black text-slate-400 w-5 text-right">#{idx + 1}</span>
                            <div>
                              <p className="text-xs font-bold text-slate-800">{user.nome}</p>
                              <p className="text-[9px] uppercase tracking-wider text-slate-400 mt-0.5">
                                {user.role === 'admin' ? 'Administrador' : 'Participante'}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-bold text-slate-900 bg-white border border-gray-200 shadow-2xs px-2.5 py-1 rounded-lg">
                              {totalFormatado}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

            </div>
          </motion.div>
        )}

        {/* VIEW 3: PLANILHA */}
        {activeView === 'planilha' && (
          <motion.div
            key="planilha"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6 max-w-4xl mx-auto w-full px-2"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn_back_to_menu_planilha"
                onClick={() => setActiveView('menu')}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 hover:text-red-500 transition-colors uppercase tracking-wider text-xs"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar ao Menu
              </button>
              <div className="text-right">
                <span className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full uppercase mr-2 inline-block">
                  Planilha de Custos
                </span>
                <span className="text-xs font-black text-white bg-slate-800 px-3 py-1 rounded-full uppercase">
                  Total: R$ {totalGeralGastos.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            {/* Admin Expense Form */}
            {currentUser?.role === 'admin' && (
              <div className="bg-slate-50 border border-gray-150 rounded-2xl p-5 space-y-4">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
                  <Plus className="h-4 w-4 text-red-500" />
                  Novo Lançamento Dedutível (Admin Only)
                </h4>
                <form onSubmit={handleAddGasto} className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Descrição</label>
                    <input
                      type="text"
                      placeholder="Ex: Aluguel da Van, Jantar Arpoador"
                      value={novaDescricao}
                      onChange={(e) => setNovaDescricao(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 border border-gray-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-1 focus:ring-red-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Valor (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      placeholder="0,00"
                      value={novoValor}
                      onChange={(e) => setNovoValor(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 border border-gray-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-1 focus:ring-red-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Categoria</label>
                    <div className="flex gap-2">
                      <select
                        value={novaCategoria}
                        onChange={(e) => setNovaCategoria(e.target.value as any)}
                        className="w-full px-2 py-1.5 border border-gray-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-1 focus:ring-red-400"
                      >
                        <option value="Moradia">Moradia</option>
                        <option value="Transporte">Transporte</option>
                        <option value="Alimentação">Alimentação</option>
                        <option value="Outros">Outros</option>
                      </select>
                      <button
                        type="submit"
                        disabled={adicionandoGasto}
                        className="bg-red-500 hover:bg-red-650 text-white p-2 rounded-xl transition-colors disabled:opacity-50"
                      >
                        {adicionandoGasto ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            )}

            {/* Categorias Planilha Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Categoria 1: Moradia */}
              <div className="bg-white rounded-3xl border border-gray-150 p-6 shadow-xs flex flex-col justify-between min-h-[220px]">
                <div className="w-full">
                  <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
                    <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">🏠 Moradia</h3>
                    <span className="text-xs font-black text-red-500">
                      R$ {moradia.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {moradia.list.map((g) => (
                      <div key={g.id} className="flex justify-between items-center text-xs text-neutral-600">
                        <span className="truncate max-w-[200px]" title={g.descricao}>{g.descricao}</span>
                        <div className="font-semibold text-slate-800 flex items-center gap-2">
                          <span>R$ {g.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                          {currentUser?.role === 'admin' && (
                            <button onClick={() => handleDeleteGasto(g.id!)} className="text-neutral-300 hover:text-red-500 transition-colors">
                              <Trash2 className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                    {moradia.list.length === 0 && (
                      <p className="text-neutral-400 italic text-[11px] py-1">Nenhum custo nesta categoria.</p>
                    )}
                  </div>
                </div>
                <div className="pt-3 border-t border-gray-100 mt-4 flex justify-between text-xs font-black text-slate-800">
                  <span>Subtotal Moradia</span>
                  <span className="text-red-600 font-extrabold">R$ {moradia.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Categoria 2: Transporte */}
              <div className="bg-white rounded-3xl border border-gray-150 p-6 shadow-xs flex flex-col justify-between min-h-[220px]">
                <div className="w-full">
                  <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
                    <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">🚗 Transporte</h3>
                    <span className="text-xs font-black text-red-500">
                      R$ {transporte.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {transporte.list.map((g) => (
                      <div key={g.id} className="flex justify-between items-center text-xs text-neutral-600">
                        <span className="truncate max-w-[200px]" title={g.descricao}>{g.descricao}</span>
                        <div className="font-semibold text-slate-800 flex items-center gap-2">
                          <span>R$ {g.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                          {currentUser?.role === 'admin' && (
                            <button onClick={() => handleDeleteGasto(g.id!)} className="text-neutral-300 hover:text-red-500 transition-colors">
                              <Trash2 className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                    {transporte.list.length === 0 && (
                      <p className="text-neutral-400 italic text-[11px] py-1">Nenhum custo nesta categoria.</p>
                    )}
                  </div>
                </div>
                <div className="pt-3 border-t border-gray-100 mt-4 flex justify-between text-xs font-black text-slate-800">
                  <span>Subtotal Transporte</span>
                  <span className="text-red-600 font-extrabold">R$ {transporte.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Categoria 3: Alimentação */}
              <div className="bg-white rounded-3xl border border-gray-150 p-6 shadow-xs flex flex-col justify-between min-h-[220px]">
                <div className="w-full">
                  <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
                    <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">🥩 Alimentação</h3>
                    <span className="text-xs font-black text-red-500">
                      R$ {alimentacao.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {alimentacao.list.map((g) => (
                      <div key={g.id} className="flex justify-between items-center text-xs text-neutral-600">
                        <span className="truncate max-w-[200px]" title={g.descricao}>{g.descricao}</span>
                        <div className="font-semibold text-slate-800 flex items-center gap-2">
                          <span>R$ {g.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                          {currentUser?.role === 'admin' && (
                            <button onClick={() => handleDeleteGasto(g.id!)} className="text-neutral-300 hover:text-red-500 transition-colors">
                              <Trash2 className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                    {alimentacao.list.length === 0 && (
                      <p className="text-neutral-400 italic text-[11px] py-1">Nenhum custo nesta categoria.</p>
                    )}
                  </div>
                </div>
                <div className="pt-3 border-t border-gray-100 mt-4 flex justify-between text-xs font-black text-slate-800">
                  <span>Subtotal Alimentação</span>
                  <span className="text-red-600 font-extrabold">R$ {alimentacao.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Categoria 4: Outros */}
              <div className="bg-white rounded-3xl border border-gray-150 p-6 shadow-xs flex flex-col justify-between min-h-[220px]">
                <div className="w-full">
                  <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
                    <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">🎟️ Outros</h3>
                    <span className="text-xs font-black text-red-500">
                      R$ {outros.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {outros.list.map((g) => (
                      <div key={g.id} className="flex justify-between items-center text-xs text-neutral-600">
                        <span className="truncate max-w-[200px]" title={g.descricao}>{g.descricao}</span>
                        <div className="font-semibold text-slate-800 flex items-center gap-2">
                          <span>R$ {g.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                          {currentUser?.role === 'admin' && (
                            <button onClick={() => handleDeleteGasto(g.id!)} className="text-neutral-300 hover:text-red-500 transition-colors">
                              <Trash2 className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                    {outros.list.length === 0 && (
                      <p className="text-neutral-400 italic text-[11px] py-1">Nenhum custo nesta categoria.</p>
                    )}
                  </div>
                </div>
                <div className="pt-3 border-t border-gray-100 mt-4 flex justify-between text-xs font-black text-slate-800">
                  <span>Subtotal Outros</span>
                  <span className="text-red-600 font-extrabold">R$ {outros.sum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

            </div>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
