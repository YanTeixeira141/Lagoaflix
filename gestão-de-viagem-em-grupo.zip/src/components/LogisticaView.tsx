import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Car, 
  CloudSun, 
  ArrowLeft, 
  MapPin, 
  Calendar, 
  Clock, 
  Compass, 
  Sun, 
  CloudRain, 
  Cloud, 
  Navigation,
  Sparkles,
  Info
} from 'lucide-react';
import { useFirebase } from '../FirebaseContext';

export default function LogisticaView() {
  const { connectionMode } = useFirebase();
  // Internal navigation: 'menu', 'transporte', 'clima'
  const [activeView, setActiveView] = useState<'menu' | 'transporte' | 'clima'>('menu');

  // Static Climate data mock
  const forecastDays = [
    {
      date: 'Qua, 18 de Nov',
      icon: CloudRain,
      max: '23°C',
      min: '14°C',
      description: 'Pancadas de chuva à tarde',
      color: 'bg-blue-50/60 border-blue-100 text-blue-600',
      tag: 'Chuva'
    },
    {
      date: 'Qui, 19 de Nov',
      icon: CloudSun,
      max: '25°C',
      min: '13°C',
      description: 'Sol com algumas nuvens',
      color: 'bg-amber-50/60 border-amber-100 text-amber-600',
      tag: 'Instável'
    },
    {
      date: 'Sex, 20 de Nov',
      icon: Sun,
      max: '27°C',
      min: '15°C',
      description: 'Ensolarado e agradável',
      color: 'bg-emerald-50/60 border-emerald-100 text-emerald-600',
      tag: 'Céu Limpo'
    },
    {
      date: 'Sáb, 21 de Nov',
      icon: Cloud,
      max: '22°C',
      min: '12°C',
      description: 'Nublado com leve névoa',
      color: 'bg-slate-50 border-slate-150 text-slate-650',
      tag: 'Nublado'
    }
  ];

  const menuContainerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 15 },
    show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <div id="logistica-view-container" className="w-full max-w-4xl mx-auto space-y-6">
      <AnimatePresence mode="wait">
        {activeView === 'menu' && (
          <motion.div
            key="logistica-menu"
            variants={menuContainerVariants}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col md:grid md:grid-cols-2 gap-5"
          >
            {/* Card 1: Transporte */}
            <motion.div
              id="btn-logistica-transporte"
              variants={cardVariants}
              onClick={() => setActiveView('transporte')}
              className="group bg-white rounded-3xl p-6 border border-gray-150 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between gap-6 transform hover:-translate-y-1 active:translate-y-0 text-left"
            >
              <div className="flex items-start gap-4">
                <div className="h-12 w-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center shrink-0 group-hover:bg-red-600 group-hover:text-white transition-colors duration-300">
                  <Car className="h-6 w-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-extrabold text-slate-800 tracking-tight group-hover:text-red-600 transition-colors">
                    Transporte e Rotas
                  </h3>
                  <p className="text-xs text-neutral-500 font-medium leading-relaxed">
                    Endereços, horários e previsão de viagem detalhada até o sítio.
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between text-[11px] font-black uppercase tracking-wider text-slate-400 group-hover:text-red-500 transition-colors">
                <span>Visualizar Rotas</span>
                <span className="text-slate-300 group-hover:translate-x-1.5 transition-transform duration-300">&rarr;</span>
              </div>
            </motion.div>

            {/* Card 2: Clima */}
            <motion.div
              id="btn-logistica-clima"
              variants={cardVariants}
              onClick={() => setActiveView('clima')}
              className="group bg-white rounded-3xl p-6 border border-gray-150 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between gap-6 transform hover:-translate-y-1 active:translate-y-0 text-left"
            >
              <div className="flex items-start gap-4">
                <div className="h-12 w-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 group-hover:bg-amber-500 group-hover:text-white transition-colors duration-300">
                  <CloudSun className="h-6 w-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-extrabold text-slate-800 tracking-tight group-hover:text-amber-600 transition-colors">
                    Previsão do Tempo
                  </h3>
                  <p className="text-xs text-neutral-500 font-medium leading-relaxed">
                    Acompanhe o clima previsto para os 4 dias da nossa hospedagem.
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between text-[11px] font-black uppercase tracking-wider text-slate-400 group-hover:text-amber-500 transition-colors">
                <span>Verificar Clima</span>
                <span className="text-slate-300 group-hover:translate-x-1.5 transition-transform duration-300">&rarr;</span>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* View 2: Transporte */}
        {activeView === 'transporte' && (
          <motion.div
            key="logistica-transporte"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn-transporte-voltar"
                onClick={() => setActiveView('menu')}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar ao Menu
              </button>
              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                Rotas de Campo Limpo Paulista
              </span>
            </div>

            {/* Container de Rota (Simulação de Mapa) */}
            <div className="bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200/60 rounded-3xl p-6 md:p-8 flex flex-col gap-6 relative overflow-hidden shadow-xs">
              <div className="absolute top-0 right-0 h-48 w-48 bg-slate-200/30 rounded-full blur-3xl pointer-events-none" />
              
              <div className="flex items-center justify-between z-10">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-red-500 animate-ping" />
                  <span className="text-[10px] text-slate-500 font-extrabold uppercase tracking-widest">Trajeto Sugerido</span>
                </div>
                <div className="px-3 py-1 bg-white/80 backdrop-blur-xs rounded-full border border-slate-250 text-[10px] font-bold text-slate-600 shadow-3xs flex items-center gap-1">
                  <Navigation className="h-3 w-3 text-red-500 shrink-0" /> Fast Route • SP-079 / SP-332
                </div>
              </div>

              {/* Connected Dots Map Animation */}
              <div className="relative flex items-center justify-between w-full px-4 md:px-12 py-6 my-2 z-10">
                {/* Partida Pin */}
                <div className="flex flex-col items-center gap-1.5 text-center relative z-20">
                  <div className="h-10 w-10 md:h-12 md:w-12 rounded-full bg-white text-red-600 flex items-center justify-center border border-slate-200 shadow-sm relative group">
                    <MapPin className="h-5 w-5" />
                    <span className="absolute -top-1 -right-1 flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                    </span>
                  </div>
                  <span className="text-[10px] font-black text-slate-800 uppercase tracking-tight">São Paulo (Partida)</span>
                </div>

                {/* Dotted Line connector */}
                <div className="absolute left-[8%] right-[8%] md:left-[18%] md:right-[18%] top-[34px] md:top-[38px] flex items-center justify-center z-10">
                  <div className="w-full border-t-[3px] border-dashed border-red-200" />
                  <div className="absolute bg-red-600 text-white font-extrabold text-[10px] px-3.5 py-1.5 rounded-full shadow-md select-none border border-red-500 animate-bounce tracking-wide uppercase">
                    Trajeto de ~65 KM
                  </div>
                </div>

                {/* Destino Pin */}
                <div className="flex flex-col items-center gap-1.5 text-center relative z-20">
                  <div className="h-10 w-10 md:h-12 md:w-12 rounded-full bg-red-600 text-white flex items-center justify-center border-2 border-white shadow-md">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <span className="text-[10px] font-black text-red-600 uppercase tracking-tight">LagoaFlix Sítio</span>
                </div>
              </div>
            </div>

            {/* Grid de Ida e Volta */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Card de Ida */}
              <div className="bg-white rounded-3xl p-6 border border-gray-150 shadow-xs text-left space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
                  <div className="h-8 w-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
                    <Calendar className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider leading-3">Viagem de Ida</h4>
                    <span className="text-[13px] font-black text-slate-800 tracking-tight">Quinta-Feira, 18 de Nov</span>
                  </div>
                </div>

                <div className="space-y-3 pt-1">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
                      <Compass className="h-3.5 w-3.5 text-slate-350" /> Local de Partida
                    </span>
                    <p className="text-[11.5px] font-bold text-slate-700 leading-relaxed pl-4.5 border-l border-slate-200">
                      Rua Paraibuna, 561 - QT. da Paineira, São Paulo/SP
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-1">
                    <div className="space-y-0.5">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
                        <Clock className="h-3 w-3 text-slate-350" /> Partida
                      </span>
                      <p className="text-xs font-black text-slate-800 pl-4">
                        20:00h
                      </p>
                    </div>

                    <div className="space-y-0.5">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
                        <Clock className="h-3 w-3 text-red-400" /> Previsão Chegada
                      </span>
                      <p className="text-xs font-black text-red-600 pl-4">
                        21:30h <span className="text-[10px] font-medium text-slate-400 block sm:inline sm:ml-1 md:block lg:inline">(1h30m)</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card de Volta */}
              <div className="bg-white rounded-3xl p-6 border border-gray-150 shadow-xs text-left space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
                  <div className="h-8 w-8 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center">
                    <Calendar className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider leading-3">Viagem de Volta</h4>
                    <span className="text-[13px] font-black text-slate-800 tracking-tight">Domingo, 21 de Nov</span>
                  </div>
                </div>

                <div className="space-y-3 pt-1">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
                      <Compass className="h-3.5 w-3.5 text-slate-350" /> Endereço do Sítio
                    </span>
                    <p className="text-[11.5px] font-bold text-slate-700 leading-relaxed pl-4.5 border-l border-slate-200">
                      Estrada Santa Clara, 435 - Estância São Paulo, Campo Limpo Paulista/SP
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-1">
                    <div className="space-y-0.5">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
                        <Clock className="h-3 w-3 text-slate-350" /> Saída do Sítio
                      </span>
                      <p className="text-xs font-black text-slate-800 pl-4">
                        15:00h
                      </p>
                    </div>

                    <div className="space-y-0.5">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
                        <Clock className="h-3 w-3 text-slate-350" /> Chegada em SP
                      </span>
                      <p className="text-xs font-black text-slate-800 pl-4">
                        16:30h <span className="text-[10px] font-medium text-slate-400 block sm:inline sm:ml-1 md:block lg:inline">(1h30m)</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Informational Widget below */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-start gap-3 text-left">
              <Info className="h-5 w-5 text-slate-550 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="text-[11px] font-extrabold uppercase text-slate-600 block tracking-wide">Diretrizes de Comboio</span>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  Importante ativarem o compartilhamento de localização no grupo da viagem 30 minutos antes da saída. Faremos uma parada rápida em posto de combustível no meio da rodovia SP-332.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* View 3: Clima */}
        {activeView === 'clima' && (
          <motion.div
            key="logistica-clima"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn-clima-voltar"
                onClick={() => setActiveView('menu')}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar ao Menu
              </button>
              <div className="flex items-center gap-1 text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                <Sparkles className="h-3 w-3 text-amber-500" /> Campo Limpo Paulista forecast
              </div>
            </div>

            {/* List of climate days */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {forecastDays.map((day, ix) => {
                const IconComp = day.icon;

                return (
                  <div 
                    key={ix}
                    className="bg-white rounded-3xl p-5 border border-gray-150 shadow-3xs hover:shadow-xs transition-all flex flex-col justify-between h-44 text-left"
                  >
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[11px] font-black text-slate-400 uppercase tracking-wider">
                          {day.date}
                        </span>
                        <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${day.color}`}>
                          {day.tag}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-2xl">
                          <IconComp className="h-6 w-6 text-slate-700" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xl font-black text-slate-800 tracking-tight leading-4">
                            {day.max}
                          </span>
                          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mt-0.5 leading-3">
                            Min: {day.min}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-gray-50">
                      <p className="text-[11px] font-bold text-slate-600 leading-snug">
                        {day.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Clima Recomendação Card */}
            <div className="bg-amber-50/45 border border-amber-100/80 rounded-2xl p-4 flex items-start gap-3 text-left">
              <CloudSun className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="text-[11px] font-extrabold uppercase text-amber-800 block tracking-wide">Dicas de Vestuário</span>
                <p className="text-xs text-amber-700 font-bold leading-relaxed">
                  As noites serão bastante amenas / frias (mínimas perto de 12°C). Recomendamos muito levar jaquetas confortáveis para as noites no sítio, mas roupas leves para curtir o sol e a piscina aquecida durante as tardes de sexta e sábado!
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
