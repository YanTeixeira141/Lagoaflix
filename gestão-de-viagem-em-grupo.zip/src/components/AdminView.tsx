import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, 
  ArrowLeft, 
  Calendar, 
  MapPin, 
  Clock, 
  Users, 
  FileSpreadsheet, 
  QrCode, 
  ShieldCheck, 
  Trash2, 
  Plus, 
  Check, 
  X, 
  Eye, 
  TrendingUp, 
  DollarSign, 
  ExternalLink,
  ShieldAlert,
  Info,
  CalendarCheck,
  Pencil
} from 'lucide-react';
import { useFirebase } from '../FirebaseContext';
import { Gasto, Pagamento, UserProfile, PRESET_PROFILES } from '../firebase';

export default function AdminView() {
  const { 
    users, 
    pagamentos, 
    gastos, 
    logistica, 
    pixKey,
    updateLogistica, 
    addGasto, 
    deleteGasto, 
    updateGasto,
    updatePagamentoStatus, 
    updatePixKey,
    updateUserRole
  } = useFirebase();

  // Internal Navigation
  const [activeView, setActiveView] = useState<'menu' | 'logistica' | 'financeiro' | 'planilha' | 'pix' | 'perfis'>('menu');

  // Local Form States
  const [logIda, setLogIda] = useState(logistica?.dataIda || '');
  const [logVolta, setLogVolta] = useState(logistica?.dataVolta || '');
  const [logPartida, setLogPartida] = useState(logistica?.enderecoPartida || '');
  const [logDestino, setLogDestino] = useState(logistica?.enderecoDestino || '');
  const [logDistancia, setLogDistancia] = useState(logistica?.distanciaKm?.toString() || '65');
  const [logTempo, setLogTempo] = useState(logistica?.tempoEstimado || '1h 30m');

  // Gasto Form States
  const [gastoDesc, setGastoDesc] = useState('');
  const [gastoValor, setGastoValor] = useState('');
  const [gastoCat, setGastoCat] = useState<'Moradia' | 'Transporte' | 'Alimentação' | 'Outros'>('Alimentação');

  // Pix Form State
  const [localPix, setLocalPix] = useState(pixKey);

  // Pre-fill sub-screens whenever data changes
  React.useEffect(() => {
    if (logistica) {
      setLogIda(logistica.dataIda || '');
      setLogVolta(logistica.dataVolta || '');
      setLogPartida(logistica.enderecoPartida || '');
      setLogDestino(logistica.enderecoDestino || '');
      setLogDistancia(logistica.distanciaKm?.toString() || '65');
      setLogTempo(logistica.tempoEstimado || '1h 30m');
    }
  }, [logistica]);

  React.useEffect(() => {
    if (pixKey) {
      setLocalPix(pixKey);
    }
  }, [pixKey]);

  // Inline Spreadsheet Editing States
  const [editingCellId, setEditingCellId] = useState<string | null>(null); // formatted as "gastoId-field" (e.g. "g1-descricao", "g1-valor")
  const [editingValue, setEditingValue] = useState<string>('');

  // Modal / Detail States
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [viewingReceiptUrl, setViewingReceiptUrl] = useState<string | null>(null);

  // Status Notification Feedback
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const triggerFeedback = (type: 'success' | 'error', msg: string) => {
    setFeedback({ type, message: msg });
    setTimeout(() => setFeedback(null), 4000);
  };

  // --------------------------------------------------------
  // Action Handlers
  // --------------------------------------------------------
  
  const handleSaveLogistica = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!logIda || !logVolta || !logPartida || !logDestino) {
      triggerFeedback('error', 'Por favor, preencha todos os campos obrigatórios da logística.');
      return;
    }
    try {
      await updateLogistica({
        dataIda: logIda,
        dataVolta: logVolta,
        enderecoPartida: logPartida,
        enderecoDestino: logDestino,
        distanciaKm: Number(logDistancia) || 0,
        tempoEstimado: logTempo || '1h 30m'
      });
      triggerFeedback('success', 'Logística da viagem atualizada com sucesso!');
    } catch (err: any) {
      console.error(err);
      triggerFeedback('error', `Erro ao salvar logística: ${err.message || err}`);
    }
  };

  const handleAddGasto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!gastoDesc.trim() || !gastoValor || Number(gastoValor) <= 0) {
      triggerFeedback('error', 'Preencha a descrição e um valor de gasto válido.');
      return;
    }
    try {
      await addGasto(gastoCat, gastoDesc.trim(), Number(gastoValor));
      setGastoDesc('');
      setGastoValor('');
      triggerFeedback('success', 'Nova despesa adicionada com sucesso!');
    } catch (err: any) {
      console.error(err);
      triggerFeedback('error', `Erro ao adicionar despesa: ${err.message || err}`);
    }
  };

  const handleDeleteGasto = async (id: string) => {
    if (!window.confirm('Tem certeza que deseja apagar esta despesa?')) return;
    try {
      await deleteGasto(id);
      triggerFeedback('success', 'Despesa removida com sucesso!');
    } catch (err: any) {
      console.error(err);
      triggerFeedback('error', `Erro ao deletar despesa: ${err.message || err}`);
    }
  };

  const handleSaveInlineCell = async (id: string, field: 'descricao' | 'valor', value: string) => {
    setEditingCellId(null);
    let finalValue: any = value;
    if (field === 'valor') {
      finalValue = Number(value);
      if (isNaN(finalValue) || finalValue < 0) {
        triggerFeedback('error', 'Valor inválido informado.');
        return;
      }
    } else {
      if (!value.trim()) {
        triggerFeedback('error', 'A descrição não pode ser vazia.');
        return;
      }
      finalValue = value.trim();
    }

    try {
      await updateGasto(id, { [field]: finalValue });
      triggerFeedback('success', 'Despesa editada com sucesso na planilha!');
    } catch (err: any) {
      triggerFeedback('error', `Falha ao salvar alteração: ${err.message || err}`);
    }
  };

  const handleAddSubtleGasto = async (category: 'Moradia' | 'Transporte' | 'Alimentação' | 'Outros') => {
    try {
      await addGasto(category, 'Nova Despesa', 0);
      triggerFeedback('success', `Nova despesa criada em ${category}. Clique na célula para customizar!`);
    } catch (err: any) {
      triggerFeedback('error', `Falha ao criar despesa: ${err.message || err}`);
    }
  };

  const handleSavePix = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!localPix.trim()) {
      triggerFeedback('error', 'A chave PIX não pode ser vazia.');
      return;
    }
    try {
      await updatePixKey(localPix.trim());
      triggerFeedback('success', 'Chave PIX atualizada no Firestore com sucesso!');
    } catch (err: any) {
      console.error(err);
      triggerFeedback('error', `Erro ao atualizar PIX: ${err.message || err}`);
    }
  };

  const handleUpdateRole = async (userId: string, newRole: 'admin' | 'user') => {
    try {
      await updateUserRole(userId, newRole);
      triggerFeedback('success', 'Nível de acesso atualizado em tempo real!');
    } catch (err: any) {
      console.error(err);
      triggerFeedback('error', `Erro ao alterar role: ${err.message || err}`);
    }
  };

  const handleApprovePayment = async (payId: string) => {
    try {
      await updatePagamentoStatus(payId, 'aprovado');
      triggerFeedback('success', 'Pagamento APROVADO com sucesso!');
    } catch (err: any) {
      console.error(err);
      triggerFeedback('error', `Falha ao aprovar pagamento: ${err.message || err}`);
    }
  };

  const handleRejectPayment = async (payId: string) => {
    try {
      await updatePagamentoStatus(payId, 'recusado');
      triggerFeedback('success', 'Pagamento recusado / rejeitado.');
    } catch (err: any) {
      console.error(err);
      triggerFeedback('error', `Falha ao recusar pagamento: ${err.message || err}`);
    }
  };

  // --------------------------------------------------------
  // Computations
  // --------------------------------------------------------
  const totalInExpenses = gastos.reduce((acc, curr) => acc + (Number(curr.valor) || 0), 0);
  const activeUsersCount = users.length || 1;
  const quotaPerPerson = totalInExpenses / activeUsersCount;

  const formatBRL = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Moradia': return 'bg-purple-50 text-purple-700 border-purple-100';
      case 'Transporte': return 'bg-cyan-50 text-cyan-700 border-cyan-100';
      case 'Alimentação': return 'bg-rose-50 text-rose-700 border-rose-100';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  // Animation constants
  const listContainerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <div id="admin-module-container" className="w-full max-w-4xl mx-auto space-y-6">
      
      {/* Dynamic inline notification banner */}
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className={`p-3.5 rounded-2xl border text-xs font-bold leading-relaxed shadow-sm text-left flex items-start gap-2.5 z-50 relative ${
              feedback.type === 'success' 
                ? 'bg-emerald-50 text-emerald-800 border-emerald-100' 
                : 'bg-rose-50 text-rose-800 border-rose-100'
            }`}
          >
            {feedback.type === 'success' ? (
              <ShieldCheck className="h-4.5 w-4.5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <ShieldAlert className="h-4.5 w-4.5 text-rose-600 shrink-0 mt-0.5" />
            )}
            <span>{feedback.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {/* ======================================================== */}
        {/* VISUAL 1: MENU INICIAL                                   */}
        {/* ======================================================== */}
        {activeView === 'menu' && (
          <motion.div
            key="admin-menu"
            variants={listContainerVariants}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <div className="text-left space-y-1">
              <span className="text-[10px] bg-red-50 text-red-600 font-extrabold uppercase tracking-widest px-3 py-1 rounded-full border border-red-100">
                Painel Administrativo
              </span>
              <h2 className="text-xl font-extrabold text-slate-800 tracking-tight mt-2 flex items-center gap-1.5">
                <Lock className="h-5 w-5 text-red-600" />
                Coordenação de Viagem
              </h2>
              <p className="text-xs text-neutral-500 font-medium leading-relaxed">
                Acesse módulos restritos para controlar finanças, autorizar Pix comprovantes, alterar logística e delegar permissões da LagoaFlix.
              </p>
            </div>

            {/* Grid of 5 Modules */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              
              {/* Card 1: Logística */}
              <motion.div
                id="btn-admin-logistica"
                variants={itemVariants}
                onClick={() => {
                  setLogIda(logistica?.dataIda || '');
                  setLogVolta(logistica?.dataVolta || '');
                  setLogPartida(logistica?.enderecoPartida || '');
                  setLogDestino(logistica?.enderecoDestino || '');
                  setLogDistancia(logistica?.distanciaKm?.toString() || '65');
                  setLogTempo(logistica?.tempoEstimado || '1h 30m');
                  setActiveView('logistica');
                }}
                className="group bg-white rounded-3xl p-5 border border-gray-150 hover:border-red-200 shadow-3xs hover:shadow-xs cursor-pointer transition-all hover:-translate-y-1 active:translate-y-0 text-left flex flex-col justify-between min-h-[224px]"
              >
                <div className="space-y-3">
                  <div className="h-10 w-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-colors duration-300">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-800 group-hover:text-red-650 transition-colors">
                      Logística e Transporte
                    </h3>
                    <p className="text-[11px] text-neutral-400 font-semibold leading-relaxed mt-0.5">
                      Altere as datas, horários e pontos de partida ou destino do sítio.
                    </p>
                  </div>
                  {/* Metric Summary */}
                  <div className="bg-red-50/50 border border-red-100 rounded-xl p-2 text-[10px] font-semibold text-slate-700">
                    📍 <span className="font-bold text-red-700">Destino:</span> {logistica?.enderecoDestino ? (logistica.enderecoDestino.split(',')[1] || logistica.enderecoDestino).trim() : 'Campo Limpo Paulista - SP'}
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 group-hover:text-red-500 duration-300">
                    Gerenciar Rota &rarr;
                  </span>
                  <span className="px-3 py-1 bg-red-600 text-white rounded-lg text-[10px] font-black tracking-tight group-hover:bg-red-700 transition">
                    Editar
                  </span>
                </div>
              </motion.div>

              {/* Card 2: Financeiro */}
              <motion.div
                id="btn-admin-financeiro"
                variants={itemVariants}
                onClick={() => setActiveView('financeiro')}
                className="group bg-white rounded-3xl p-5 border border-gray-150 hover:border-emerald-200 shadow-3xs hover:shadow-xs cursor-pointer transition-all hover:-translate-y-1 active:translate-y-0 text-left flex flex-col justify-between min-h-[224px]"
              >
                <div className="space-y-3">
                  <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-300">
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-800 group-hover:text-emerald-650 transition-colors">
                      Financeiro (Participantes)
                    </h3>
                    <p className="text-[11px] text-neutral-400 font-semibold leading-relaxed mt-0.5">
                      Controle de pagamentos de parcelas e aprove comprovantes emitidos.
                    </p>
                  </div>
                  {/* Metric Summary */}
                  <div className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-2 text-[10px] font-semibold text-slate-700">
                    👥 <span className="font-bold text-emerald-700">Participantes:</span> {users.length} • <span className="font-bold text-emerald-700">Cota:</span> {formatBRL(quotaPerPerson)}
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 group-hover:text-emerald-500 duration-300">
                    Ver Depósitos &rarr;
                  </span>
                  <span className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-black tracking-tight group-hover:bg-emerald-700 transition">
                    Editar
                  </span>
                </div>
              </motion.div>

              {/* Card 3: Planilha (Gastos) */}
              <motion.div
                id="btn-admin-planilha"
                variants={itemVariants}
                onClick={() => setActiveView('planilha')}
                className="group bg-white rounded-3xl p-5 border border-gray-150 hover:border-purple-200 shadow-3xs hover:shadow-xs cursor-pointer transition-all hover:-translate-y-1 active:translate-y-0 text-left flex flex-col justify-between min-h-[224px]"
              >
                <div className="space-y-3">
                  <div className="h-10 w-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors duration-300">
                    <FileSpreadsheet className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-800 group-hover:text-purple-650 transition-colors">
                      Planilha (Gastos)
                    </h3>
                    <p className="text-[11px] text-neutral-400 font-semibold leading-relaxed mt-0.5">
                      CRUD de despesas com cálculo dinâmico do custo individual.
                    </p>
                  </div>
                  {/* Metric Summary */}
                  <div className="bg-purple-50/50 border border-purple-100 rounded-xl p-2 text-[10px] font-semibold text-slate-700">
                    💰 <span className="font-bold text-purple-700">Gastos Totais:</span> {formatBRL(totalInExpenses)}
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 group-hover:text-purple-500 duration-300">
                    Cadastrar Contas &rarr;
                  </span>
                  <span className="px-3 py-1 bg-purple-600 text-white rounded-lg text-[10px] font-black tracking-tight group-hover:bg-purple-700 transition">
                    Editar
                  </span>
                </div>
              </motion.div>

              {/* Card 4: Chave PIX */}
              <motion.div
                id="btn-admin-pix"
                variants={itemVariants}
                onClick={() => {
                  setLocalPix(pixKey);
                  setActiveView('pix');
                }}
                className="group bg-white rounded-3xl p-5 border border-gray-150 hover:border-amber-200 shadow-3xs hover:shadow-xs cursor-pointer transition-all hover:-translate-y-1 active:translate-y-0 text-left flex flex-col justify-between min-h-[224px]"
              >
                <div className="space-y-3">
                  <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:bg-amber-550 group-hover:text-white transition-colors duration-300">
                    <QrCode className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-800 group-hover:text-amber-605 transition-colors">
                      Chave PIX Coleta
                    </h3>
                    <p className="text-[11px] text-neutral-400 font-semibold leading-relaxed mt-0.5">
                      Edite as chaves oficiais do Pix visíveis nas abas públicas para cópia rápido.
                    </p>
                  </div>
                  {/* Metric Summary */}
                  <div className="bg-amber-50/50 border border-amber-100 rounded-xl p-2 text-[10px] font-mono font-semibold text-slate-700 truncate">
                    🔑 <span className="font-sans font-bold text-amber-700">Chave:</span> {pixKey || 'Não cadastrada'}
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 group-hover:text-amber-600 duration-300">
                    Chave Bancária &rarr;
                  </span>
                  <span className="px-3 py-1 bg-amber-500 text-white rounded-lg text-[10px] font-black tracking-tight group-hover:bg-amber-600 transition">
                    Editar
                  </span>
                </div>
              </motion.div>

              {/* Card 5: Perfis de Acesso */}
              <motion.div
                id="btn-admin-perfis"
                variants={itemVariants}
                onClick={() => setActiveView('perfis')}
                className="group bg-white rounded-3xl p-5 border border-gray-150 hover:border-blue-200 shadow-3xs hover:shadow-xs cursor-pointer transition-all hover:-translate-y-1 active:translate-y-0 text-left flex flex-col justify-between min-h-[224px]"
              >
                <div className="space-y-3">
                  <div className="h-10 w-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-800 group-hover:text-blue-650 transition-colors">
                      Perfis de Acesso (Roles)
                    </h3>
                    <p className="text-[11px] text-neutral-400 font-semibold leading-relaxed mt-0.5">
                      Promova participantes para Administrador ou mude permissões no sistema.
                    </p>
                  </div>
                  {/* Metric Summary */}
                  <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-2 text-[10px] font-semibold text-slate-700">
                    🛡️ <span className="font-bold text-blue-700">Admins:</span> {users.filter(u => u.role === 'admin').length} • <span className="font-bold text-blue-700">Viajantes:</span> {users.filter(u => u.role !== 'admin').length}
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 group-hover:text-blue-500 duration-300">
                    Regras de Acesso &rarr;
                  </span>
                  <span className="px-3 py-1 bg-blue-600 text-white rounded-lg text-[10px] font-black tracking-tight group-hover:bg-blue-700 transition">
                    Editar
                  </span>
                </div>
              </motion.div>

            </div>
          </motion.div>
        )}

        {/* ======================================================== */}
        {/* VISUAL 2: LOGÍSTICA                                      */}
        {/* ======================================================== */}
        {activeView === 'logistica' && (
          <motion.div
            key="admin-logistica"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn-logistica-voltar"
                onClick={() => setActiveView('menu')}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </button>
              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                Módulo Logística (Documento viagem_info)
              </span>
            </div>

            <form onSubmit={handleSaveLogistica} className="bg-white rounded-3xl border border-gray-150 p-6 md:p-8 space-y-6 text-left shadow-3xs">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="text-base font-extrabold text-slate-800 tracking-tight">Editar Localizações e Horários</h3>
                <p className="text-[11px] text-neutral-500 font-semibold leading-relaxed mt-0.5">
                  Preencha os campos abaixo para sincronizar a rota no aplicativo geral de todos de forma real-time.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                
                {/* Partida data */}
                <div className="space-y-1.5">
                  <label className="text-[10.5px] uppercase font-black tracking-wider text-slate-500">Data e Hora de Partida</label>
                  <input
                    type="datetime-local"
                    value={logIda}
                    onChange={(e) => setLogIda(e.target.value)}
                    className="w-full text-xs font-bold px-3.5 py-2.5 bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:border-red-500 focus:bg-white transition"
                    required
                  />
                </div>

                {/* Retorno data */}
                <div className="space-y-1.5">
                  <label className="text-[10.5px] uppercase font-black tracking-wider text-slate-500">Data e Hora de Retorno</label>
                  <input
                    type="datetime-local"
                    value={logVolta}
                    onChange={(e) => setLogVolta(e.target.value)}
                    className="w-full text-xs font-bold px-3.5 py-2.5 bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:border-red-500 focus:bg-white transition"
                    required
                  />
                </div>

                {/* Endereço Partida */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[10.5px] uppercase font-black tracking-wider text-slate-500 flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5 text-slate-400" /> Endereço de Partida
                  </label>
                  <input
                    type="text"
                    value={logPartida}
                    onChange={(e) => setLogPartida(e.target.value)}
                    className="w-full text-xs font-bold px-3.5 py-2.5 bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:border-red-500 focus:bg-white transition"
                    placeholder="Ex: Rua Paraibuna, 561 - Paineiras, São Paulo/SP"
                    required
                  />
                </div>

                {/* Endereço Destino */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[10.5px] uppercase font-black tracking-wider text-slate-500 flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5 text-slate-400" /> Endereço do Sítio (Destino)
                  </label>
                  <input
                    type="text"
                    value={logDestino}
                    onChange={(e) => setLogDestino(e.target.value)}
                    className="w-full text-xs font-bold px-3.5 py-2.5 bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:border-red-500 focus:bg-white transition"
                    placeholder="Ex: Estrada Santa Clara, 435 - Estância São Paulo, Campo Limpo Paulista/SP"
                    required
                  />
                </div>

                {/* Distância */}
                <div className="space-y-1.5">
                  <label className="text-[10.5px] uppercase font-black tracking-wider text-slate-500">Distância da Viagem (KM)</label>
                  <input
                    type="number"
                    value={logDistancia}
                    onChange={(e) => setLogDistancia(e.target.value)}
                    className="w-full text-xs font-bold px-3.5 py-2.5 bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:border-red-500 focus:bg-white transition"
                    placeholder="Ex: 65"
                  />
                </div>

                {/* Tempo Estimado */}
                <div className="space-y-1.5">
                  <label className="text-[10.5px] uppercase font-black tracking-wider text-slate-500">Tempo Estimado</label>
                  <input
                    type="text"
                    value={logTempo}
                    onChange={(e) => setLogTempo(e.target.value)}
                    className="w-full text-xs font-bold px-3.5 py-2.5 bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:border-red-500 focus:bg-white transition"
                    placeholder="Ex: 1h 30m"
                  />
                </div>

              </div>

              <div className="flex justify-end pt-3">
                <button
                  id="btn-salvar-logistica"
                  type="submit"
                  className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black tracking-tight transition shadow-sm cursor-pointer"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {/* ======================================================== */}
        {/* VISUAL 3: PLANILHA / GASTOS                             */}
        {/* ======================================================== */}
        {activeView === 'planilha' && (
          <motion.div
            key="admin-planilha"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn-planilha-voltar"
                onClick={() => setActiveView('menu')}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </button>
              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                Planilha de Custos Interativa (LagoaFlix)
              </span>
            </div>

            {/* Calculations Banner */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              
              <div className="bg-slate-900 text-white rounded-3xl p-6 text-left flex items-center justify-between shadow-xs">
                <div>
                  <span className="text-[9.5px] uppercase font-bold text-slate-300 tracking-wider">Valor Total da Viagem</span>
                  <p className="text-2xl font-black tracking-tight mt-1">
                    {formatBRL(totalInExpenses)}
                  </p>
                  <p className="text-[10px] text-slate-400 font-medium leading-relaxed mt-1">
                    Soma de todas as despesas cadastradas abaixo.
                  </p>
                </div>
                <div className="h-12 w-12 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
                  <TrendingUp className="h-6 w-6 text-emerald-400" />
                </div>
              </div>

              <div className="bg-white rounded-3xl p-6 text-left border border-gray-150 flex items-center justify-between shadow-3xs">
                <div>
                  <span className="text-[9.5px] uppercase font-bold text-neutral-400 tracking-wider">Cota por Pessoa</span>
                  <p className="text-2xl font-black text-rose-600 tracking-tight mt-1">
                    {formatBRL(quotaPerPerson)}
                  </p>
                  <p className="text-[10px] text-neutral-400 font-medium leading-relaxed mt-1">
                    {formatBRL(totalInExpenses)} dividido por {activeUsersCount} participantes ativos.
                  </p>
                </div>
                <div className="h-12 w-12 rounded-2xl bg-rose-50 flex items-center justify-center shrink-0">
                  <DollarSign className="h-6 w-6 text-rose-500" />
                </div>
              </div>

            </div>

            {/* Spreadsheet Sections (4 Interactive Tables, one for each category) */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {(['Moradia', 'Transporte', 'Alimentação', 'Outros'] as const).map((cat) => {
                const catExpenses = gastos.filter(g => g.categoria === cat);
                const catTotal = catExpenses.reduce((sum, g) => sum + g.valor, 0);

                return (
                  <div key={cat} className="bg-white rounded-3xl border border-gray-150 p-6 space-y-4 shadow-3xs text-left">
                    <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                      <div className="flex items-center gap-2">
                        <span className={`h-2.5 w-2.5 rounded-full ${
                          cat === 'Moradia' ? 'bg-indigo-500' :
                          cat === 'Transporte' ? 'bg-cyan-500' :
                          cat === 'Alimentação' ? 'bg-emerald-500' : 'bg-purple-500'
                        }`} />
                        <h4 className="text-sm font-black text-slate-800 tracking-tight">{cat}</h4>
                        <span className="text-[9px] font-bold text-slate-400">({catExpenses.length})</span>
                      </div>
                      
                      {/* Subtle plus button for fast quick-adding to the precise category */}
                      <button
                        type="button"
                        onClick={() => handleAddSubtleGasto(cat)}
                        className="flex items-center gap-1 px-2.5 py-1 text-[10px] font-extrabold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-slate-100 border border-indigo-100 hover:border-slate-300 rounded-lg transition shrink-0 cursor-pointer"
                        title={`Rápido adicionar em ${cat}`}
                      >
                        <Plus className="h-3 w-3 stroke-[3px]" /> Adicionar
                      </button>
                    </div>

                    <div className="overflow-x-auto min-h-[140px]">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-gray-100 text-[10px] font-black uppercase tracking-wider text-slate-400">
                            <th className="py-2 px-1">Descrição (Clique para editar)</th>
                            <th className="py-2 px-1 text-right w-36">Valor (R$)</th>
                            <th className="py-2 px-1 text-center w-12">Remover</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {catExpenses.length === 0 ? (
                            <tr>
                              <td colSpan={3} className="py-8 px-1 text-center text-[11px] text-neutral-400 font-medium">
                                Nenhuma despesa em {cat}. Use o botão "+ Adicionar" acima.
                              </td>
                            </tr>
                          ) : (
                            catExpenses.map((g) => {
                              const isEditingDesc = editingCellId === `${g.id}-descricao`;
                              const isEditingValor = editingCellId === `${g.id}-valor`;

                              return (
                                <tr key={g.id} className="hover:bg-slate-50/50 transition">
                                  {/* Célula de Descrição */}
                                  <td className="py-2 px-1">
                                    {isEditingDesc ? (
                                      <input
                                        type="text"
                                        value={editingValue}
                                        onChange={(e) => setEditingValue(e.target.value)}
                                        onBlur={() => handleSaveInlineCell(g.id, 'descricao', editingValue)}
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter') {
                                            handleSaveInlineCell(g.id, 'descricao', editingValue);
                                          } else if (e.key === 'Escape') {
                                            setEditingCellId(null);
                                          }
                                        }}
                                        className="w-full text-xs font-bold px-2 py-1 bg-white border-2 border-indigo-500 rounded focus:outline-none shadow-sm"
                                        autoFocus
                                      />
                                    ) : (
                                      <span
                                        onClick={() => {
                                          setEditingCellId(`${g.id}-descricao`);
                                          setEditingValue(g.descricao);
                                        }}
                                        className="block cursor-pointer px-2 py-1 hover:bg-slate-100 rounded border border-transparent hover:border-gray-200 transition text-xs font-semibold text-slate-800"
                                        title="Clique para editar"
                                      >
                                        {g.descricao}
                                      </span>
                                    )}
                                  </td>

                                  {/* Célula de Valor */}
                                  <td className="py-2 px-1 text-right">
                                    {isEditingValor ? (
                                      <input
                                        type="number"
                                        step="0.01"
                                        value={editingValue}
                                        onChange={(e) => setEditingValue(e.target.value)}
                                        onBlur={() => handleSaveInlineCell(g.id, 'valor', editingValue)}
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter') {
                                            handleSaveInlineCell(g.id, 'valor', editingValue);
                                          } else if (e.key === 'Escape') {
                                            setEditingCellId(null);
                                          }
                                        }}
                                        className="w-full text-xs font-black text-right px-2 py-1 bg-white border-2 border-indigo-500 rounded focus:outline-none shadow-sm"
                                        autoFocus
                                      />
                                    ) : (
                                      <span
                                        onClick={() => {
                                          setEditingCellId(`${g.id}-valor`);
                                          setEditingValue(g.valor.toString());
                                        }}
                                        className="block cursor-pointer px-2 py-1 hover:bg-slate-100 rounded border border-transparent hover:border-gray-200 transition text-right text-xs font-black text-slate-700"
                                        title="Clique para editar"
                                      >
                                        {formatBRL(g.valor)}
                                      </span>
                                    )}
                                  </td>

                                  {/* Botão de Excluir */}
                                  <td className="py-2 px-1 text-center">
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteGasto(g.id)}
                                      className="p-1 px-1.5 text-slate-400 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 border border-slate-150 hover:border-rose-100 rounded-lg transition shrink-0 cursor-pointer"
                                      title="Apagar despesa"
                                    >
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                        {/* Auto-summation Footer */}
                        <tfoot>
                          <tr className="border-t border-slate-100">
                            <td className="py-2 px-2 text-[10px] font-black uppercase tracking-wider text-slate-400">
                              Subtotal {cat}:
                            </td>
                            <td className="py-2 px-2 text-right text-[11px] font-black text-slate-800">
                              {formatBRL(catTotal)}
                            </td>
                            <td />
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* ======================================================== */}
        {/* VISUAL 4: FINANCEIRO / PARTICIPANTES                     */}
        {/* ======================================================== */}
        {activeView === 'financeiro' && (
          <motion.div
            key="admin-financeiro"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn-financeiro-voltar"
                onClick={() => setActiveView('menu')}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </button>
              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-slate-100 border border-slate-200 text-slate-600 font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full">
                  Cota Individual: {formatBRL(quotaPerPerson)}
                </span>
                <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                  Módulo Financeiro / Pagamentos
                </span>
              </div>
            </div>

            {/* Users table showing payments status & access levels */}
            <div className="bg-white rounded-3xl border border-gray-150 p-6 md:p-8 space-y-4 text-left shadow-3xs overflow-x-auto">
              <div className="border-b border-gray-105 pb-3">
                <h3 className="text-base font-extrabold text-slate-800 tracking-tight">Gerenciamento de Participantes</h3>
                <p className="text-[11px] text-neutral-500 font-semibold leading-relaxed mt-0.5">
                  Mude permissões no sistema em tempo real, aprove comprovantes e confira o status de quitação de cada cota.
                </p>
              </div>

              <table className="w-full text-slate-800 text-left min-w-[620px]">
                <thead>
                  <tr className="border-b border-gray-150 text-[10px] font-black uppercase tracking-wider text-slate-400">
                    <th className="py-3 px-4">Participante</th>
                    <th className="py-3 px-2">Nível de Acesso (Role)</th>
                    <th className="py-3 px-4">Total Pago</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Comprovantes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {users.map((u) => {
                    const isPaid = u.totalPago >= quotaPerPerson;
                    const preset = PRESET_PROFILES.find(p => p.id === u.id);
                    return (
                      <tr key={u.id} className="hover:bg-slate-50/50 transition">
                        {/* Nome do Participante */}
                        <td className="py-4 px-4 flex items-center gap-2.5">
                          <div className={`h-8 w-8 rounded-full ${preset?.color || 'bg-slate-300'} flex items-center justify-center text-xs text-white font-black overflow-hidden shrink-0`}>
                            {u.avatarUrl ? (
                              <img src={u.avatarUrl} alt={u.nome} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              u.nome.charAt(0)
                            )}
                          </div>
                          <div>
                            <span className="text-xs font-black text-slate-800 block">{u.nome}</span>
                            <span className="text-[9px] font-semibold text-slate-400 font-mono block uppercase leading-none mt-0.5">ID: {u.id}</span>
                          </div>
                        </td>

                        {/* Nível de Acesso (Role) */}
                        <td className="py-4 px-2">
                          <select
                            id={`select-role-financeiro-${u.id}`}
                            value={u.role}
                            onChange={(e) => handleUpdateRole(u.id, e.target.value as 'admin' | 'user')}
                            className="text-xs font-black px-2 py-1 bg-slate-50 border border-gray-200 rounded-lg focus:outline-none cursor-pointer hover:bg-slate-100 transition"
                          >
                            <option value="user">Viajante (user)</option>
                            <option value="admin">Coordenador (admin)</option>
                          </select>
                        </td>

                        {/* Total Pago */}
                        <td className="py-4 px-4 text-xs font-black text-slate-700">
                          {formatBRL(u.totalPago || 0)}
                        </td>

                        {/* Status (Quitado / Devendo) */}
                        <td className="py-4 px-4">
                          <div className="flex justify-center">
                            {isPaid ? (
                              <span className="bg-emerald-50 text-emerald-700 border border-emerald-200/50 rounded-full px-2.5 py-0.5 flex items-center gap-1 text-[9.5px] font-black uppercase tracking-wider">
                                <Check className="h-3 w-3 text-emerald-600 stroke-[3px]" /> Quitado
                              </span>
                            ) : (
                              <span className="bg-amber-50 text-amber-700 border border-amber-200/50 rounded-full px-2.5 py-0.5 inline-block text-[9.5px] font-black uppercase tracking-wider">
                                Devendo
                              </span>
                            )}
                          </div>
                        </td>

                        {/* Ação */}
                        <td className="py-4 px-4 text-right">
                          <button
                            id={`btn-ver-historico-${u.id}`}
                            onClick={() => setSelectedUser(u)}
                            className="inline-flex py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-black tracking-tight transition items-center gap-1 cursor-pointer"
                          >
                            <Eye className="h-3.5 w-3.5" /> Histórico
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Individual Payments History Modal / Drawer for the Selected Participant */}
            <AnimatePresence>
              {selectedUser && (
                <div className="fixed inset-0 bg-[#121212c4] backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white rounded-3xl border border-gray-200 w-full max-w-lg p-6 relative shadow-2xl text-left"
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-gray-150 mb-4">
                      <div>
                        <span className="text-[10px] text-purple-600 font-extrabold uppercase tracking-widest block">Histórico de Comprovantes</span>
                        <h3 className="text-base font-black text-slate-800 tracking-tight leading-4 mt-0.5">
                          {selectedUser.nome}
                        </h3>
                      </div>
                      <button
                        id="btn-fechar-historico"
                        onClick={() => setSelectedUser(null)}
                        className="p-1.5 text-neutral-400 hover:text-slate-800 rounded-full hover:bg-slate-50 transition border border-gray-150 cursor-pointer"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>

                    {/* Content List */}
                    <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
                      {pagamentos.filter((p) => p.uid === selectedUser.id).length === 0 ? (
                        <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-gray-200/80 text-xs text-slate-400">
                          Este participante ainda não enviou nenhum comprovante de pagamento no sistema.
                        </div>
                      ) : (
                        pagamentos
                          .filter((p) => p.uid === selectedUser.id)
                          .map((p) => (
                            <div key={p.id} className="bg-slate-50 p-4 rounded-2xl border border-gray-150 space-y-3">
                              <div className="flex items-start justify-between">
                                <div className="space-y-0.5">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{p.mesRef}</span>
                                    <span className={`text-[8.5px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                                      p.status === 'aprovado' 
                                        ? 'bg-emerald-50 text-emerald-700 border-emerald-100'
                                        : p.status === 'recusado'
                                        ? 'bg-rose-50 text-rose-700 border-rose-100'
                                        : 'bg-amber-50 text-amber-700 border-amber-100'
                                    }`}>
                                      {p.status}
                                    </span>
                                  </div>
                                  <p className="text-sm font-black text-slate-800">{formatBRL(p.valor)}</p>
                                </div>

                                <button
                                  id={`btn-open-doc-${p.id}`}
                                  onClick={() => setViewingReceiptUrl(p.comprovanteUrl)}
                                  className="text-[10px] font-black text-purple-600 hover:text-purple-700 underline flex items-center gap-0.5 cursor-pointer bg-white px-2.5 py-1 rounded-lg border border-slate-150 shadow-3xs"
                                >
                                  Visualizar <ExternalLink className="h-3 w-3 ml-0.5" />
                                </button>
                              </div>

                              {/* Admin actions block */}
                              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-150">
                                {p.status !== 'recusado' && (
                                  <button
                                    id={`btn-recusar-comprovante-${p.id}`}
                                    onClick={() => handleRejectPayment(p.id)}
                                    className="px-3 py-1.5 bg-white border border-rose-200 hover:border-rose-400 text-rose-600 text-[10.5px] font-black uppercase tracking-wider rounded-xl transition cursor-pointer flex items-center gap-1"
                                  >
                                    <X className="h-3.5 w-3.5 stroke-[3px]" /> Recusar
                                  </button>
                                )}
                                {p.status !== 'aprovado' && (
                                  <button
                                    id={`btn-aprovar-comprovante-${p.id}`}
                                    onClick={() => handleApprovePayment(p.id)}
                                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-[10.5px] font-black uppercase tracking-wider rounded-xl transition cursor-pointer shadow-sm flex items-center gap-1"
                                  >
                                    <Check className="h-3.5 w-3.5 stroke-[3px]" /> Aprovar
                                  </button>
                                )}
                              </div>
                            </div>
                          ))
                      )}
                    </div>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>

            {/* Proof Zoom / Popup Modal Preview */}
            <AnimatePresence>
              {viewingReceiptUrl && (
                <div className="fixed inset-0 bg-[#000000f0] p-4 flex items-center justify-center z-[100]">
                  <div className="absolute top-4 right-4 flex items-center gap-2">
                    <a
                      href={viewingReceiptUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-black tracking-tight transition flex items-center gap-1"
                    >
                      Abrir em nova aba <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                    <button
                      id="btn-close-receipt-zoom"
                      onClick={() => setViewingReceiptUrl(null)}
                      className="p-1.5 text-white/70 hover:text-white bg-white/10 rounded-full transition"
                    >
                      <X className="h-4.5 w-4.5" />
                    </button>
                  </div>
                  <img
                    src={viewingReceiptUrl}
                    alt="Expanded Zoom Comprovante"
                    className="max-w-full max-h-[85vh] object-contain rounded-2xl shadow-xl border border-white/15"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* ======================================================== */}
        {/* VISUAL 5: DEPÓSITO VIA PIX                              */}
        {/* ======================================================== */}
        {activeView === 'pix' && (
          <motion.div
            key="admin-pix"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn-pix-voltar"
                onClick={() => setActiveView('menu')}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </button>
              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                Módulo Pagamento / PIX Coleta
              </span>
            </div>

            <form onSubmit={handleSavePix} className="bg-white rounded-3xl border border-gray-150 p-6 md:p-8 space-y-5 text-left shadow-3xs">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="text-base font-extrabold text-slate-800 tracking-tight">Editar Chave PIX Oficial</h3>
                <p className="text-[11px] text-neutral-500 font-semibold leading-relaxed mt-0.5">
                  Informe a chave Pix que os participantes devem utilizar para realizar os depósitos coletivos e as mensalidades da viagem.
                </p>
              </div>

              <div className="space-y-1.5 max-w-md">
                <label className="text-[10.5px] uppercase font-black tracking-wider text-slate-500 flex items-center gap-1">
                  <QrCode className="h-3.5 w-3.5 text-slate-400 font-normal" /> Chave PIX da Coleta
                </label>
                <input
                  type="text"
                  value={localPix}
                  onChange={(e) => setLocalPix(e.target.value)}
                  className="w-full text-xs font-mono font-bold px-3.5 py-3 bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:border-amber-550 focus:bg-white transition"
                  placeholder="Ex: yan.turismo@viagemgrupo.com ou e-mail/celular"
                  required
                />
                <span className="text-[9.5px] text-neutral-400 font-semibold block leading-normal mt-1">
                  Dica: Você pode inserir uma chave de e-mail, telefone, CPF, ou chave aleatória tradicional.
                </span>
              </div>

              <div className="flex justify-end pt-3">
                <button
                  id="btn-salvar-pix"
                  type="submit"
                  className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black tracking-tight transition shadow-sm cursor-pointer"
                >
                  Salvar Chave Pix
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {/* ======================================================== */}
        {/* VISUAL 6: PERFIS                                         */}
        {/* ======================================================== */}
        {activeView === 'perfis' && (
          <motion.div
            key="admin-perfis"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5"
          >
            {/* Header / Voltar */}
            <div className="flex items-center justify-between">
              <button
                id="btn-perfis-voltar"
                onClick={() => setActiveView('menu')}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </button>
              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                Módulo Segurança (Regras do Firestore)
              </span>
            </div>

            <div className="bg-white rounded-3xl border border-gray-150 p-6 md:p-8 space-y-6 text-left shadow-3xs">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="text-base font-extrabold text-slate-800 tracking-tight">Perfis de Acesso de Usuários</h3>
                <p className="text-[11px] text-neutral-500 font-semibold leading-relaxed mt-0.5">
                  Promova ou mude papéis de acesso no Firestore em tempo real. Usuários com acesso "Administrador" conseguem visualizar esta aba de ferramentas administrativas.
                </p>
              </div>

              {/* Grid of users settings list */}
              <div className="space-y-3">
                <div className="bg-slate-50 px-4 py-2 flex items-center justify-between rounded-xl border border-slate-150 text-[10px] font-black uppercase tracking-wider text-slate-500">
                  <span>Nome / Perfil</span>
                  <span>Papel de Acesso (Role)</span>
                </div>

                <div className="divide-y divide-gray-100">
                  {users.map((user) => (
                    <div key={user.id} className="py-3.5 flex items-center justify-between">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          {user.role === 'admin' && (
                            <ShieldCheck className="h-4 w-4 text-red-500 shrink-0" />
                          )}
                          <span className="text-xs font-black text-slate-800">{user.nome}</span>
                        </div>
                        <p className="text-[10px] text-neutral-400 font-medium">
                          ID Perfil: <span className="font-mono text-[9px] uppercase">{user.id}</span> {user.email ? `• ${user.email}` : '• Sem e-mail cadastrado'}
                        </p>
                      </div>

                      {/* Select input toggle */}
                      <div className="flex items-center gap-2">
                        <select
                          id={`select-role-${user.id}`}
                          value={user.role}
                          onChange={(e: any) => handleUpdateRole(user.id, e.target.value as 'admin' | 'user')}
                          className="text-xs font-black tracking-tight px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-lg focus:outline-none cursor-pointer hover:bg-slate-100 transition"
                        >
                          <option value="user">Participante</option>
                          <option value="admin">Administrador</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
